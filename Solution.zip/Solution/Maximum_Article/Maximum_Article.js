     /* jshint esversion: 6 */

import React from 'react';
import renderHTML from 'react-render-html';

import { SITE_NAME } from "../Constants";
import ContentList from '../common/ContentList.js';
import ContentItem from '../common/ContentItem.js';
import ItemMultiValues from '../common/ItemMultiValues.js';
import Searchbar from '../common/Searchbar.js';

var rootPath = '/';

class Maximum_Article extends React.Component {
	render() {
		var id, search, limit, orderBy, offset;
		if (this.props.match && this.props.match.params) {
			id = this.props.match.params.id;
			search = this.props.match.params.search;
			limit = this.props.match.params.limit;
			orderBy = this.props.match.params.orderBy;
            offset = this.props.match.params.offset;
		}
		if (id) {
			return (
				<ContentItem site={SITE_NAME} language={this.props.language} id={id} contentLayout={ Maximum_ArticleDetail} />
			);
		} else if (search) {
			//
			// You can also set orderBy and limit, e.g:
			//  orderBy: name:asc | name:des | updatedDate:des | updatedDate:asc
			//  limit: 20
			// If not set, the default value for orderBy is updatedDate:des and the default value for limit is 10
			var queryParam = {
				type: 'Maximum_Article',
				searchString: search
			};
			if (limit) {
				queryParam['limit'] = limit;
			}
			if (orderBy) {
				queryParam['orderBy'] = orderBy;
			}
            if (offset) {
				queryParam['offset'] = offset;
			}
			return (
				<div>
				<ContentList site={SITE_NAME} language={this.props.language} query={queryParam} contentLayout={ Maximum_ArticleSummary} />
				</div>
			);
		} else {
			//
			// You can also set orderBy and limit, e.g:
			//  orderBy: name:asc | name:des | updatedDate:des | updatedDate:asc
			//  limit: 20
			// If not set, the default value for orderBy is updatedDate:des and the default value for limit is 10
			var queryParam = {
				type: 'Maximum_Article'
			};
			if (limit) {
				queryParam['limit'] = limit;
			}
			if (orderBy) {
				queryParam['orderBy'] = orderBy;
			}
            if (offset) {
				queryParam['offset'] = offset;
			}
			return (
				<div>
				<ContentList site={SITE_NAME} language={this.props.language} query={queryParam} contentLayout={ Maximum_ArticleSummary} />
				</div>
			);
		}
   	}
}

class Maximum_ArticleSummary extends React.Component {
	render() {
		var item = this.props.item;
		if (!item || !item.id) {
			return (
				<div />
			);
		}
		var detailUrl = (this.props.language ? '/' + this.props.language  : '') + '/Maximum_Article/' + item.id;
		return (
			<div className="col-sm-1 col-md-4 col-lg-4">
				<div className="animated bounceInUp">
				<a className="noUnderline" href={ detailUrl }>
                        <img className="img-rounded" src={ '/api/content/published/api/v1.1/assets/' + item.fields['maximum_article_image_1000x562']['id'] + '/native' }/>
                    <div className="text-center text-body">
                        <div className="text-sm-center text-uppercase font-weight-bold">{item['name']}</div>
                        <div className="text-sm-center">{item['description']}</div>
                    </div>
                </a>
				</div>
			 </div>
		);
	}
}

class Maximum_ArticleDetail extends React.Component {
	render() {
		var item = this.props.item;
		if (!item || !item.id) {
			return (
				<div />
			);
		}
		return (
			<div className="col">
			<div className="text-sm-center text-uppercase font-weight-bold animated fadeInDown"> <h1>{item['name']}</h1> </div>
            <div className="animated slideInUp topImage">
			     {item.fields['maximum_article_image_1000x562'] ? <img src={ '/api/content/published/api/v1.1/assets/' + item.fields['maximum_article_image_1000x562']['id'] + '/native' } /> : <span />}
            </div>
            <div className="text-justify animated fadeInDown">
			     <div>{renderHTML(item.fields['maximum_article_content'])}</div>
            </div>
            <div className="text-justify animated fadeInDown">
			     {item.fields['maximum_article_date'] ? <span>{item.fields['maximum_article_date']['value']}</span> : <span />}
            </div>
			</div>
		);

	}
}      

export default Maximum_Article;

