/* jshint esversion: 6 */

import React from 'react'
import { Route, Switch } from 'react-router'
import { Redirect } from 'react-router'
import PropTypes from 'prop-types'
import { ConnectedRouter } from 'connected-react-router'
import Maximum_Article from '../Maximum_Article/Maximum_Article'
import Maximum_Tire from '../Maximum_Tire/Maximum_Tire'
import { SITE_NAME } from '../Constants.js'
import Searchbar from '../common/Searchbar.js'
import LocaleSwitcher from '../common/LocaleSwitcher.js'
import PageNotFound from '../assets/PageNotFound.png';
import '../assets/app.css';
import '../assets/animate.css';
import '../assets/bootstrap.min.css'; 
import logo from '../assets/logo.png';
  
var rootPath = '/';

const App = ({ history }) => {
	var tireProps = {match: {params: {offset: 2,orderBy: "updatedDate:des"}}}
	return (
		<ConnectedRouter history={history}>
		<div>
		<Switch>
		<Route exact path={rootPath} render={props =><ContentSwitcher {...props} ContentComp={ Maximum_Article } site={SITE_NAME} contentType='Maximum_Article'/>} />
		<Route exact path={rootPath + 'Maximum_Article'} render={props =><ContentSwitcher {...props} ContentComp={ Maximum_Article } site={SITE_NAME} contentType='Maximum_Article'/>} />
		<Route path={rootPath + 'Maximum_Article/search/:search'} render={props =><ContentSwitcher {...props} ContentComp={ Maximum_Article } site={SITE_NAME} contentType='Maximum_Article'/>} />
		<Route path={rootPath + 'Maximum_Article/:id'} render={props =><ContentSwitcher {...props} ContentComp={ Maximum_Article } site={SITE_NAME} contentType='Maximum_Article'/>} />
		<Route exact path={rootPath + 'Maximum_Tire'} render={props =><ContentSwitcher {...tireProps} ContentComp={ Maximum_Tire } site={SITE_NAME} contentType='Maximum_Tire'/>} />
		<Route path={rootPath + 'Maximum_Tire/search/:search'} render={props =><ContentSwitcher {...props} ContentComp={ Maximum_Tire } site={SITE_NAME} contentType='Maximum_Tire'/>} />
		<Route path={rootPath + 'Maximum_Tire/:id'} render={props =><ContentSwitcher {...props} ContentComp={ Maximum_Tire } site={SITE_NAME} contentType='Maximum_Tire'/>} />

		<Route component={NotFound} />
		</Switch>
		</div>
		</ConnectedRouter>
 	 )
}

const Header = (props) => {
	var language = props.language;
	var typePath = language ? rootPath + language + '/' : rootPath;
	if (props.match.params.search) {
		return (            
			<nav className="navbar">				
			<div className="navbar-header">
				<a className="navbar-brand" href="index.html"><img src="https://shenzhuoce-orasejapan.cec.ocp.oraclecloud.com/content/published/api/v1.1/assets/CONT3B57D36FD2F64E3D9A19ACC421F36AA3/native/maximum-logo.jpg?channelToken=70fcb318c31ea3c0f4e7eada0e2c8da8" alt="" /></a>
				<h1 className="navbar-brand">{SITE_NAME}</h1>
			</div>
			<div>
				<ul className="nav justify-content-end">
					<li className="nav-item"><a className="nav-link" href={ rootPath + 'Maximum_Article' }>Home</a> </li>
					<li className="nav-item"><a className="nav-link" href={ rootPath + 'Maximum_Tire' }>Articles</a> </li>
				</ul>
                <LocaleSwitcher {...props}  />	
			</div>
			</nav>	
		)
	} else {
		return (
			<nav className="navbar">				
			<div className="navbar-header">
				<a className="navbar-brand" href="index.html"><img src="https://shenzhuoce-orasejapan.cec.ocp.oraclecloud.com/content/published/api/v1.1/assets/CONT3B57D36FD2F64E3D9A19ACC421F36AA3/native/maximum-logo.jpg?channelToken=70fcb318c31ea3c0f4e7eada0e2c8da8" alt="" /></a>
				<h1 className="navbar-brand">{SITE_NAME}</h1>
			</div>
			<div>
				<ul className="nav justify-content-end">
					<li className="nav-item"><a className="nav-link" href={ rootPath + 'Maximum_Article' }>Home</a> </li>
					<li className="nav-item"><a className="nav-link" href={ rootPath + 'Maximum_Tire' }>Articles</a> </li>
				</ul>
                <LocaleSwitcher {...props}  />
				<Searchbar {...props}  />		
			</div>
			</nav>	
		)
	}
}




class ContentSwitcher extends React.Component {
	render() {
		var bannerProps = {match: {params: {limit: 1,orderBy: "updatedDate:des"}}}
		if (this.props.match.params.search) {
			return (
				<div className="SearchResult">
				<Header {...this.props}/>
				<Maximum_Tire {...bannerProps}/>
				<Searchbar {...this.props}  />
				<this.props.ContentComp {...this.props}/>
				</div>
			);
		} else {
			return (
				<div>
				<Header {...this.props}/>
				<Maximum_Tire {...bannerProps}/>
				<this.props.ContentComp {...this.props}/>
				</div>
			);
		}
	}
}


const NotFound = () => (
<div>
<center><img src={PageNotFound}  /></center>
<center><a href={rootPath}>Return to Home Page</a></center>
</div>
);

App.propTypes = {
  history: PropTypes.object,
}

export default App
