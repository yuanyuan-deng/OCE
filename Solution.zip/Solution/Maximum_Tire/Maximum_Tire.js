     /* jshint esversion: 6 */

import React from 'react';
import renderHTML from 'react-render-html';

import { SITE_NAME } from "../Constants";
import ContentList from '../common/ContentList.js';
import ContentItem from '../common/ContentItem.js';
import ItemMultiValues from '../common/ItemMultiValues.js';
import Searchbar from '../common/Searchbar.js';

var rootPath = '/';

class Maximum_Tire extends React.Component {
	render() {
		var id, search, limit, orderBy, offset;
		if (this.props.match && this.props.match.params) {
			id = this.props.match.params.id;
			search = this.props.match.params.search;
			limit = this.props.match.params.limit;
			orderBy = this.props.match.params.orderBy;
            offset = this.props.match.params.offset;
		}
		if (id) {
			return (
				<ContentItem site={SITE_NAME} language={this.props.language} id={id} contentLayout={ Maximum_TireDetail} />
			);
		} else if (search) {
			//
			// You can also set orderBy and limit, e.g:
			//  orderBy: name:asc | name:des | updatedDate:des | updatedDate:asc
			//  limit: 20
			// If not set, the default value for orderBy is updatedDate:des and the default value for limit is 10
			var queryParam = {
				type: 'Maximum_Tire',
				searchString: search
			};
			if (limit) {
				queryParam['limit'] = limit;
			}
			if (orderBy) {
				queryParam['orderBy'] = orderBy;
			}
            if (offset) {
				queryParam['offset'] = offset;
			}
			return (
				<div>
				<ContentList site={SITE_NAME} language={this.props.language} query={queryParam} contentLayout={ Maximum_TireSummary} />
				</div>
			);
		} else {
			//
			// You can also set orderBy and limit, e.g:
			//  orderBy: name:asc | name:des | updatedDate:des | updatedDate:asc
			//  limit: 20
			// If not set, the default value for orderBy is updatedDate:des and the default value for limit is 10
			var queryParam = {
				type: 'Maximum_Tire'
			};
			if (limit) {
				queryParam['limit'] = limit;
			}
			if (orderBy) {
				queryParam['orderBy'] = orderBy;
			}
            if (offset) {
				queryParam['offset'] = offset;
			}
			return (
				<div>
				<ContentList site={SITE_NAME} language={this.props.language} query={queryParam} contentLayout={ Maximum_TireSummary} />
				</div>
			);
		}
   	}
}

class Maximum_TireSummary extends React.Component {
	render() {
		var item = this.props.item;
		if (!item || !item.id) {
			return (
				<div />
			);
		}
		var detailUrl = (this.props.language ? '/' + this.props.language  : '') + '/Maximum_Tire/' + item.id;
		return (
			<div className="col-sm-12 col-md-12 col-lg-12">
				<div className="animated bounceInUp">
				<a className="noUnderline" href={ detailUrl }>
                        <img className="img-rounded" src={ '/api/content/published/api/v1.1/assets/' + item.fields['maximum_tire_image_1440x700']['id'] + '/native' }/>
                    <div className="text-center text-body">
                        <div className="text-lg-center text-uppercase font-weight-bold"><h2>{item['name']}</h2></div>
                        <div className="text-sm-center"><h3>{item['description']}</h3></div>
                    </div>
                    <div className="Overlay"> <img className="img-fluid img-rounded" src={ '/api/content/published/api/v1.1/assets/' + item.fields['maximum_tire_image_725x700']['id'] + '/native' }/></div>
                </a>
				</div>
			 </div>
		);
	}
}

class Maximum_TireDetail extends React.Component {
	render() {
		var item = this.props.item;
		if (!item || !item.id) {
			return (
				<div />
			);
		}
		return (
			<div className="col">
			<div className="text-sm-center text-uppercase font-weight-bold animited fadeInDown">
					<h1>{item['name']}</h1>
			</div>
            <div className="animated slideInUp">
			     {item.fields['maximum_tire_image_1440x700'] ? <img src={ '/api/content/published/api/v1.1/assets/' + item.fields['maximum_tire_image_1440x700']['id'] + '/native' } /> : <span />}
            </div>
            <div className="text-justify animated fadeInDown">
			     <div>{renderHTML(item.fields['maximum_tire_content'])}</div>
            </div>
			</div>
		);
	}
}      

export default Maximum_Tire;

