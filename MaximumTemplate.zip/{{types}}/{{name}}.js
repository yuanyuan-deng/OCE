     /* jshint esversion: 6 */

import React from 'react';
import renderHTML from 'react-render-html';

import { SITE_NAME } from "../Constants";
import ContentList from '../common/ContentList.js';
import ContentItem from '../common/ContentItem.js';
import ItemMultiValues from '../common/ItemMultiValues.js';
import Searchbar from '../common/Searchbar.js';

var rootPath = '/';

class {{type}} extends React.Component {
	render() {
		var id, search, limit, orderBy, offset;
		if (this.props.match && this.props.match.params) {
			id = this.props.match.params.id;
			search = this.props.match.params.search;
			limit = this.props.match.params.limit;
			orderBy = this.props.match.params.orderBy;
            offset = this.props.match.params.offset;
		}
		if (id) {
			return (
				<ContentItem site={SITE_NAME} language={this.props.language} id={id} contentLayout={ {{type}}Detail} />
			);
		} else if (search) {
			//
			// You can also set orderBy and limit, e.g:
			//  orderBy: name:asc | name:des | updatedDate:des | updatedDate:asc
			//  limit: 20
			// If not set, the default value for orderBy is updatedDate:des and the default value for limit is 10
			var queryParam = {
				type: '{{type}}',
				searchString: search
			};
			if (limit) {
				queryParam['limit'] = limit;
			}
			if (orderBy) {
				queryParam['orderBy'] = orderBy;
			}
            if (offset) {
				queryParam['offset'] = offset;
			}
			return (
				<div>
				<ContentList site={SITE_NAME} language={this.props.language} query={queryParam} contentLayout={ {{type}}Summary} />
				</div>
			);
		} else {
			//
			// You can also set orderBy and limit, e.g:
			//  orderBy: name:asc | name:des | updatedDate:des | updatedDate:asc
			//  limit: 20
			// If not set, the default value for orderBy is updatedDate:des and the default value for limit is 10
			var queryParam = {
				type: '{{type}}'
			};
			if (limit) {
				queryParam['limit'] = limit;
			}
			if (orderBy) {
				queryParam['orderBy'] = orderBy;
			}
            if (offset) {
				queryParam['offset'] = offset;
			}
			return (
				<div>
				<ContentList site={SITE_NAME} language={this.props.language} query={queryParam} contentLayout={ {{type}}Summary} />
				</div>
			);
		}
   	}
}

class {{type}}Summary extends React.Component {
	render() {
		var item = this.props.item;
		if (!item || !item.id) {
			return (
				<div />
			);
		}
		var detailUrl = (this.props.language ? '/' + this.props.language  : '') + '/{{type}}/' + item.id;
		return (
			<div className="col-sm-1 col-md-4 col-lg-4">
				<div className="animated bounceInUp">
				<a className="noUnderline" href={ detailUrl }>
                    {{#fields}}
                    {{#__render.forsummary}}
                        {{#__render.image}}
                        <img className="img-rounded" src={ '/api/content/published/api/v1.1/assets/' + item.fields['{{name}}']['id'] + '/native' }/>
                        {{/__render.image}}
                    {{/__render.forsummary}}
                    {{/fields}}
                    <div className="text-center text-body">
                        <div className="text-sm-center text-uppercase font-weight-bold">{item['name']}</div>
                        <div className="text-sm-center">{item['description']}</div>
                    </div>
                </a>
				</div>
			 </div>
		);
	}
}

class {{type}}Detail extends React.Component {
	render() {
		var item = this.props.item;
		if (!item || !item.id) {
			return (
				<div />
			);
		}
		return (
			<div className="col">
			{{#fields}}
			{{#__render.single}}
			{{#__render.direct}}
            <div className="text-justify animated fadeInDown">
			     <span>{item.fields['{{name}}']}</span>
            </div>
			{{/__render.direct}}
			{{#__render.image}}
            <div className="animated slideInUp">
			     {item.fields['{{name}}'] ? <img src={ '/api/content/published/api/v1.1/assets/' + item.fields['{{name}}']['id'] + '/native' } /> : <span />}
            </div>
			{{/__render.image}}
			{{#__render.datetime}}
            <div className="text-justify animated fadeInDown">
			     {item.fields['{{name}}'] ? <span>{item.fields['{{name}}']['value']}</span> : <span />}
            </div>
			{{/__render.datetime}}
			{{#__render.richtext}}
            <div className="text-justify animated fadeInDown">
			     <div>{renderHTML(item.fields['{{name}}'])}</div>
            </div>
			{{/__render.richtext}}
			{{#__render.reference}}
			{{#langugeEnabled}}
            <div className="text-justify animated fadeInDown">
			     {item.fields['{{name}}'] ? <span><a href={ rootPath + item.fields['{{name}}']['language'] + '/' + item.fields['{{name}}']['type'] + '/' + item.fields['{{name}}']['id'] }>{item.fields['{{name}}']['type']}{item.fields['{{name}}']['name'] ? ':' + item.fields['{{name}}']['name'] : ''}</a></span> : <span />}
            </div>
			{{/langugeEnabled}}
			{{^langugeEnabled}}
			{item.fields['{{name}}'] ? <span><a href={ rootPath + item.fields['{{name}}']['type'] + '/' + item.fields['{{name}}']['id'] }>{item.fields['{{name}}']['type']}{item.fields['{{name}}']['name'] ? ':' + item.fields['{{name}}']['name'] : ''}</a></span> : <span />}
			{{/langugeEnabled}}
			{{/__render.reference}}
			{{/__render.single}}
			{{#__render.multiple}}
			{{#__render.direct}}
            <div className="text-justify animated fadeInDown">
			     <ItemMultiValues type='direct' values={item.fields['{{name}}']}/>
            </div>
			{{/__render.direct}}
			{{#__render.image}}
            <div className="text-justify animated fadeInDown">
			     <ItemMultiValues type='image' values={item.fields['{{name}}']}/>
            </div>
			{{/__render.image}}
			{{#__render.richtext}}
            <div className="text-justify animated fadeInDown">
			     <ItemMultiValues type='richtext' values={item.fields['{{name}}']}/>
            </div>
			{{/__render.richtext}}
			{{#__render.reference}}
            <div className="text-justify animated fadeInDown">
			     <ItemMultiValues type='reference' values={item.fields['{{name}}']}/>
            </div>
			{{/__render.reference}}
			{{/__render.multiple}}
			{{/fields}}
			</div>
		);
	}
}      

export default {{type}};

