/* jshint esversion: 6 */

export const SITE_NAME = '{{sitename}}';

export const LOCALES = [{{{localenames}}}];
