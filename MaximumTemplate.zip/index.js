

import React from 'react';
import ReactDOM from 'react-dom';
import { Provider } from 'react-redux';
import { createStore, applyMiddleware } from 'redux';
import { createBrowserHistory } from 'history';
import { Route, Switch } from 'react-router';
import { connectRouter, routerMiddleware } from 'connected-react-router';
import thunk from 'redux-thunk';

import queryReducer from './common/queryReducer';
import App from './app/App.js';

const history = createBrowserHistory();
const store = createStore(connectRouter(history)(queryReducer),  applyMiddleware(thunk));

ReactDOM.render(
<Provider store={store}>
<App history={history} />
</Provider>,
document.getElementById('root')
);
