

/* globals console */
/* jshint esversion: 6 */
import React from 'react';

import { LOCALES } from "../Constants";

class LocaleSwitcher extends React.Component {
	state = {
		selectedLocale: ''
	};

	handleChange = (event) => {
		var currLocale = this.props.language,
			newLocale = event.target.value;
		// console.log('curr locale: ' + currLocale + ' new locale: ' + newLocale);

		// Save the new selection
		this.setState({ selectedLocale: newLocale });

		if (currLocale && newLocale && currLocale !== newLocale) {
			var url = this.props.match.url;
			url = url.replace('/'+currLocale, '/'+newLocale);
			this.props.history.push(url);
		}
	};

	render() {
		var selectedLocale = this.state.selectedLocale || this.props.language;

		if (LOCALES.length <= 1) {
			return (
				<div />
			);
		}
		
		var lang = '';

		var options = [];
		for(var i = 0; i < LOCALES.length; i++) {
			var locale = LOCALES[i];
			options[i] =  <option value={locale} key={locale}>{locale}</option>;
		}

		return(
			<div className="Locales">
				<select value={selectedLocale} onChange={this.handleChange}>
					{options}
				</select>
			</div>
		);
	}
}

export default LocaleSwitcher;
