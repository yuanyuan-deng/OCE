/* globals console */
/* jshint esversion: 6 */
import React from 'react';
import { connect } from "react-redux";
import PropTypes from 'prop-types';

import { queryItems } from './queryItems';
import { SITE_NAME } from "../Constants";

class Searchbar extends React.Component {
	
	search(e)  {
		var url = '/' + (this.props.language ? this.props.language + '/' : '') + this.props.contentType + '/search/' + this.state.search;
		this.props.history.push(url);
	}

	render() {
		var defaultVal = this.props.match.params.search;
		return (
			<form className="Search" action="#">
			<input type="text" placeholder="Search..."
				defaultValue={defaultVal}
				onChange={event => {this.setState({search: event.target.value})}}
				onKeyPress={event => {
					if (event.key === 'Enter') {
                  				this.search()
                			}
				}}
			/>
			</form>
		)
	}
}

export default Searchbar;
